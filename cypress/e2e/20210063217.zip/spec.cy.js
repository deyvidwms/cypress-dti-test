describe("testes 2", () => {
  // Todo describe deve ter um beforeEach exatamente
  // como o que está abaixo. A falta desse trecho de
  // código vai acarretar nota zero no processo de
  // correção automática.
  beforeEach(() => {
    let host = Cypress.env("TEST_HOST") || 'https://todomvc.com/examples/angular/dist/browser/#/all';
    cy.visit(host);
  });

  // abaixo você pode criar os testes que desejar
  // para testar a aplicação em questão.
  it("Verificar se a página está apresentando os elementos de título h1 e input", () => {
    cy.get('h1').should('have.text', 'Todos');
    cy.get('input[placeholder="What needs to be done?"]').should('exist');
  });

  it("Verificar se o TodoMVC está inserindo uma tarefa", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.get('.todo-list li').should('have.length', 1).and('contain', 'Nova Tarefa');
  });

  it("Verificar se uma tarefa recém criada aparece no filtro 'Active'", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.contains('Active').click();
    cy.get('.todo-list li').should('have.length', 1).and('contain', 'Nova Tarefa');
  });

  it("Verificar se o botão 'Clear completed' está funcionando", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.get('.todo-list li .toggle').click();
    cy.get(`button.clear-completed`).click();
    cy.get('.todo-list li').should('have.length', 0);
  });

  it("Verificar se múltiplas tarefas podem ser adicionadas", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Tarefa 1{enter}');
    cy.get('input[placeholder="What needs to be done?"]').type('Tarefa 2{enter}');
    cy.get('input[placeholder="What needs to be done?"]').type('Tarefa 3{enter}');
    cy.get('.todo-list li').should('have.length', 3);
  });

  it("Verificar se uma tarefa pode ser marcada como completa", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.get('.todo-list li .toggle').click();
    cy.get('.todo-list li').should('have.class', 'completed');
  });

  it("Verificar se uma tarefa pode ser editada", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.get('.todo-list li').dblclick();
    cy.get('.todo-list li.editing .edit').clear().type('Tarefa Editada{enter}');
    cy.get('.todo-list li').should('contain', 'Tarefa Editada');
  });

  it("Verificar se uma tarefa pode ser removida", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.get('.todo-list li .destroy').click({ force: true });
    cy.get('.todo-list li').should('have.length', 0);
  });

  it("Verificar se o filtro 'Completed' está funcionando", () => {
    cy.get('input[placeholder="What needs to be done?"]').type('Nova Tarefa{enter}');
    cy.get('.todo-list li .toggle').click();
    cy.contains('Completed').click();
    cy.get('.todo-list li').should('have.length', 1).and('contain', 'Nova Tarefa');
  });
});